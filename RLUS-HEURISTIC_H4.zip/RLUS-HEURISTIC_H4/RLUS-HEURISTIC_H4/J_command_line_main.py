import argparse
import os
import pandas as pd
import logging
from J_RLUS import set_rho
import math

# Setup basic logging with debug level
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

def load_theta(data_path):
    try:
        logging.debug(f"Loading data from {data_path}")
        data = pd.read_csv(data_path)
        theta = data['delay'].tolist()
        logging.debug(f"Data loaded successfully, {len(theta)} rows found")
        return theta
    except Exception as e:
        logging.error(f"Failed to load data from {data_path}: {e}")
        exit(1)

def main():
    parser = argparse.ArgumentParser(description="Run the RLUS algorithm.")
    parser.add_argument("--data_path", type=str, required=True, help="Path to the CSV data file.")
    parser.add_argument("--q", type=float, default=0.5, help="Quantile to estimate.")
    parser.add_argument("--delta_target", type=float, default=0.05, help="Target confidence level.")
    parser.add_argument("--epsilon_min", type=float, help="Minimum epsilon value.")
    parser.add_argument("--epsilon_max", type=float, help="Maximum epsilon value.")
    parser.add_argument("--b", type=int, default=1000, help="Number of bootstrap resamples.")
    parser.add_argument("--result_path", type=str, required=True, help="Path to save the results.")
    parser.add_argument("--result_file", type=str, required=True, help="File to save the results.")
    parser.add_argument("--tau", type=float, default=0.05, help="Early stopping threshold.")

    args = parser.parse_args()
    logging.info(f"Running RLUS with parameters: q={args.q}, delta_target={args.delta_target}, epsilon_range=({args.epsilon_min},{args.epsilon_max}), b={args.b}, tau={args.tau}")

    theta = load_theta(args.data_path)
    epsilon_range = (args.epsilon_min, args.epsilon_max)

    logging.debug(f"Calculating beta and k based on theta size: {len(theta)}")
    beta = round(math.sqrt(len(theta)) * 3)
    k = round(beta -1)

    logging.info(f"Computed parameters: beta={beta}, k={k}")

    try:
        logging.debug(f"Calling set_rho with beta={beta}, k={k}")
        largest_accepted_rho = set_rho(args.q, args.delta_target, epsilon_range, beta, k, args.tau, theta, args.b)
        logging.info(f"Computed largest_accepted_rho: {largest_accepted_rho}")
    except Exception as e:
        logging.error(f"Error computing largest accepted rho: {e}")
        exit(1)

    result = {
        "epsilon_range": f"({epsilon_range[0]},{epsilon_range[1]})",
        "largest_accepted_rho": largest_accepted_rho
    }
    df = pd.DataFrame([result])
    full_path = os.path.join(args.result_path, args.result_file)

    try:
        logging.debug(f"Saving results to {full_path}")
        if os.path.isfile(full_path):
            df.to_csv(full_path, mode='a', header=False, index=False)
        else:
            df.to_csv(full_path, mode='w', header=True, index=False)
        logging.info(f"Results saved successfully to {full_path}")
    except Exception as e:
        logging.error(f"Failed to save results to {full_path}: {e}")

if __name__ == "__main__":
    main()
