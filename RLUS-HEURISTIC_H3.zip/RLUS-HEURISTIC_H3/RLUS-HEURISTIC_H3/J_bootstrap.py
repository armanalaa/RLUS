import numpy as np

def bootstrap(theta, n, delta_target, q, b):

    print(f"q={q}")

    theta = np.asarray(theta).flatten()
    n = min(n, len(theta))

    if len(theta) == 0:
        raise ValueError("Input data (theta) is empty.")

    if n <= 0 or not isinstance(n, int):
        raise ValueError("Sample size (n) must be a positive integer.")

    if n > len(theta):
        n = len(theta)  # Adjust n to the maximum allowable size

    epsilons = []

    S_0 = np.random.choice(theta, size=n, replace=True)
    x_0 = np.quantile(S_0, q)

    for _ in range(b):
        S_i = np.random.choice(theta, size=n, replace=True)
        x_i = np.quantile(S_i, q)
        epsilons.append(abs(x_i - x_0))

    epsilons.sort()

    # Calculate the index to select epsilon
    s_index = int(1 + b * (delta_target / 2)) - 1

    # Ensure s_index is within the bounds of epsilons
    if s_index < 0 or s_index >= len(epsilons):
        raise ValueError(f"s_index {s_index} is out of bounds for epsilons with length {len(epsilons)}")

    print(f"s_index: {s_index}")
    print(f"epsilons[s_index]: {epsilons[s_index]}")

    return epsilons[s_index]
