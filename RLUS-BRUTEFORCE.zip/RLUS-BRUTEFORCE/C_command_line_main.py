import argparse
import os
import pandas as pd
from C_RLUS import set_rho


def load_theta(data_path):
    data = pd.read_csv(data_path)
    theta = data['delay'].tolist()
    return theta


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run the RLUS algorithm.")
    parser.add_argument("--data_path", type=str, required=True, help="Path to the CSV data file.")
    parser.add_argument("--q", type=float, default=0.5, help="Quantile to estimate.")
    parser.add_argument("--delta_target", type=float, default=0.05, help="Target confidence level.")
    parser.add_argument("--epsilon_min", type=float, default=120, help="Minimum epsilon value.")
    parser.add_argument("--epsilon_max", type=float, default=240, help="Maximum epsilon value.")
    parser.add_argument("--b", type=int, default=1000, help="Number of bootstrap resamples.")
    parser.add_argument("--result_path", type=str, required=True, help="Path to save the results.")
    parser.add_argument("--result_file", type=str, required=True, help="file to save the results.")

    args = parser.parse_args()

    theta = load_theta(args.data_path)
    epsilon_range = (args.epsilon_min, args.epsilon_max)

    print(f"min: {args.epsilon_min}, max: {args.epsilon_max}")
    print(f"------")

    # results = set_rho(args.q, args.delta_target, epsilon_range, theta, args.b)

    largest_accepted_rho = set_rho(args.q, args.delta_target, epsilon_range, theta, args.b)


    # if largest_accepted_rho is not None:
    input_base_name = os.path.splitext(os.path.basename(args.result_path))[0]
    # filename = f"epsilon_{args.epsilon_min}-{args.epsilon_max}_firstRho_{results.get('first_acceptable_rho', 'NA')}_largestRho_{results.get('largest_accepted_rho', 'NA')}.csv"
    filename = f"results.csv"
    full_path = os.path.join(args.result_path, args.result_file)

    # Convert the results to a DataFrame
    result = {
        "epsilon_range": f"({epsilon_range[0]},{epsilon_range[1]})",
        "largest_accepted_rho": largest_accepted_rho
    }
    df = pd.DataFrame([result])

    # If the file exists, append without writing the header
    if os.path.isfile(full_path):
        df.to_csv(full_path, mode='a', header=False, index=False)
    else:
        df.to_csv(full_path, mode='w', header=True, index=False)

    # # Prepare DataFrame for export
    # export_results = {
    #     "accepted_rhos": results.get("accepted_rhos", []),
    #     "accepted_epsilons": results.get("accepted_epsilons", []),
    #     "difference_medians": results.get("difference_medians", []),
    #     "difference_median_epsilons": results.get("difference_median_epsilons", []),
    # }

    # results_df = pd.DataFrame(export_results)

    # results_df.to_csv(full_path, index=False)
    print(f"Results have been saved to {full_path}")
else:
    print("Error: No results to save.")
