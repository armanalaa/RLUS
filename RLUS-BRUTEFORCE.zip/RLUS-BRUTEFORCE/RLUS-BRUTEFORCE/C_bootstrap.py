import numpy as np


def bootstrap(theta, n, delta_target, q, b):
    theta = np.asarray(theta).flatten()
    n = min(n, len(theta))

    if len(theta) == 0:
        raise ValueError("Input data (theta) is empty.")

    if n <= 0 or not isinstance(n, int):
        raise ValueError("Sample size (n) must be a positive integer.")

    if n > len(theta):
        n = len(theta)  # Adjust n to the maximum allowable size

    epsilons = []

    S_0 = np.random.choice(theta, size=n, replace=True)
    x_0 = np.quantile(S_0, q)

    for _ in range(b):
        S_i = np.random.choice(theta, size=n, replace=True)
        x_i = np.quantile(S_i, q)
        epsilons.append(abs(x_i - x_0))

    epsilons.sort()

    # Calculate the index to select epsilon
    s_index = int(1 + b * (delta_target / 2)) - 1
    print(f"s_index: {s_index}")
    print(f"epsilons[s_index]: {epsilons[s_index]}")

    return epsilons[s_index]