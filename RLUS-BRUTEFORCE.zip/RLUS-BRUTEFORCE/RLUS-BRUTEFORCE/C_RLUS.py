import numpy as np
from C_bootstrap import bootstrap


def set_rho(q, delta_target, epsilon_range, theta, b):
    accepted_rhos = []
    epsilon_min, epsilon_max = epsilon_range
    accepted_epsilons = []
    n = len(theta)

    while n > 0:
        print(f"-------------------")

        current_epsilon = bootstrap(theta, n, delta_target, q, b)

        # Append to lists appropriately
        if epsilon_min <= current_epsilon <= epsilon_max:
            n = n - 1
            accepted_rhos.append(n)  # Store the accepted rho

            print(
                f"epsilon_min: {epsilon_min}, epsilon_max: {epsilon_max}, n={n}, new accepted rho: {n}, new accepted_epsilon: {current_epsilon}")
            accepted_epsilons.append(current_epsilon)

        else:  # current_epsilon > epsilon_max
            n = n - 1
            print(
                f"epsilon_min: {epsilon_min}, epsilon_max: {epsilon_max}, no accepted epsilon and rho found, new n: {n}")

    accepted_rhos.sort()
    largest_accepted_rho = accepted_rhos[-1] if accepted_rhos else None
    print(f"epsilon_min: {epsilon_min}, epsilon_max: {epsilon_max}, largest_accepted_rho: {largest_accepted_rho}")

    return largest_accepted_rho
