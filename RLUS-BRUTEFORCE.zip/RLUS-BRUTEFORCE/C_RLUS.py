import numpy as np
from C_bootstrap import bootstrap


def set_rho(q, delta_target, epsilon_range, theta, b):
    # median_theta = np.median(theta)  # Calculate the median of theta
    median_differences = []
    first_acceptable_rho_found = False
    first_acceptable_rho = None
    accepted_rhos = []
    difference_medians = []
    difference_median_epsilons = []
    epsilon_min, epsilon_max = epsilon_range
    accepted_epsilons = []
    E_i = []
    n = len(theta)

    while n > 0:
        # candidate_rhos.append(n)
        print(f"-------------------")
        # print(f"candidate_rhos: {candidate_rhos}")

        # bootstrap_result = bootstrap(theta, n, delta_target, q, b, median_theta)
        # current_epsilon = bootstrap_result["current_epsilon"]
        #

        current_epsilon = bootstrap(theta, n, delta_target, q, b)

        # difference_median = bootstrap_result["difference_median"]
        # difference_median_epsilon = bootstrap_result["difference_median_epsilon"]  # This should be a scalar

        # Append to lists appropriately
        if epsilon_min <= current_epsilon <= epsilon_max:
            n = n - 1
            accepted_rhos.append(n)  # Store the accepted rho

            # difference_medians.append(difference_median)
            # difference_median_epsilons.append(difference_median_epsilon)  # Ensure this is the correct list name

            print(
                f"epsilon_min: {epsilon_min}, epsilon_max: {epsilon_max}, n={n}, new accepted rho: {n}, new accepted_epsilon: {current_epsilon}")
            accepted_epsilons.append(current_epsilon)

            # if not first_acceptable_rho_found:
            #     first_acceptable_rho = n
            #     print(
            #         f"epsilon_min: {epsilon_min}, epsilon_max: {epsilon_max}, first_acceptable_rho: {first_acceptable_rho}")
            #     first_acceptable_rho_found = True

        else:  # current_epsilon > epsilon_max
            n = n - 1
            print(
                f"epsilon_min: {epsilon_min}, epsilon_max: {epsilon_max}, no accepted epsilon and rho found, new n: {n}")

    accepted_rhos.sort()
    largest_accepted_rho = accepted_rhos[-1] if accepted_rhos else None
    # print(f"epsilon_min: {epsilon_min}, epsilon_max: {epsilon_max}, first_acceptable_rho: {first_acceptable_rho}")
    print(f"epsilon_min: {epsilon_min}, epsilon_max: {epsilon_max}, largest_accepted_rho: {largest_accepted_rho}")

    # return {
    #     "accepted_rhos": accepted_rhos,
    #     "accepted_epsilons": accepted_epsilons,
    #     "difference_medians": difference_medians,
    #     "difference_median_epsilons": difference_median_epsilons,
    #     "first_acceptable_rho": first_acceptable_rho,
    #     "largest_accepted_rho": largest_accepted_rho
    # }

    return largest_accepted_rho
