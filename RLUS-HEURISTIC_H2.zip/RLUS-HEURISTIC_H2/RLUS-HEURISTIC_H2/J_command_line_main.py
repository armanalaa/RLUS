import argparse
import os
import pandas as pd
import logging
from J_RLUS import set_rho
import math

# Setup basic logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

def load_theta(data_path):
    try:
        logging.debug(f"Attempting to load data from {data_path}")
        data = pd.read_csv(data_path)
        theta = data['delay'].tolist()
        logging.debug(f"Data loaded successfully from {data_path}, total records: {len(theta)}")
        return theta
    except Exception as e:
        logging.error(f"Failed to load data from {data_path}: {e}")
        exit(1)

def main():
    parser = argparse.ArgumentParser(description="Run the RLUS algorithm.")
    parser.add_argument("--data_path", type=str, required=True, help="Path to the CSV data file.")
    parser.add_argument("--q", type=float, default=0.5, help="Quantile to estimate.")
    parser.add_argument("--delta_target", type=float, default=0.05, help="Target confidence level.")
    parser.add_argument("--epsilon_min", type=float, help="Minimum epsilon value.")
    parser.add_argument("--epsilon_max", type=float, help="Maximum epsilon value.")
    parser.add_argument("--b", type=int, default=1000, help="Number of bootstrap resamples.")
    parser.add_argument("--result_path", type=str, required=True, help="Path to save the results.")
    parser.add_argument("--result_file", type=str, required=True, help="File to save the results.")
    parser.add_argument("--tau", type=float, default=0.01, help="Early stopping threshold.")

    args = parser.parse_args()
    
    # Log the received arguments for debugging
    logging.debug(f"Received arguments: {args}")
    
    theta = load_theta(args.data_path)
    epsilon_range = (args.epsilon_min, args.epsilon_max)
    
    # Calculate beta and k with debug information
    size_theta = len(theta)
    beta = round(2 * math.sqrt(size_theta))
    k = round(beta - 1)
    
    logging.debug(f"Calculated parameters: size_theta={size_theta}, beta={beta}, k={k}")
    
    try:
        logging.info(f"Starting set_rho computation with q={args.q}, delta_target={args.delta_target}, epsilon_range={epsilon_range}, beta={beta}, k={k}, tau={args.tau}")
        largest_accepted_rho = set_rho(args.q, args.delta_target, epsilon_range, beta, k, args.tau, theta, args.b)
        logging.info(f"Largest accepted rho computed: {largest_accepted_rho}")
    except Exception as e:
        logging.error(f"Error computing largest accepted rho: {e}")
        exit(1)

    result = {
        "epsilon_range": f"({epsilon_range[0]},{epsilon_range[1]})",
        "largest_accepted_rho": largest_accepted_rho
    }
    df = pd.DataFrame([result])
    full_path = os.path.join(args.result_path, args.result_file)

    try:
        if os.path.isfile(full_path):
            df.to_csv(full_path, mode='a', header=False, index=False)
            logging.debug(f"Appended results to existing file at {full_path}")
        else:
            df.to_csv(full_path, mode='w', header=True, index=False)
            logging.debug(f"Saved results to a new file at {full_path}")
        logging.info(f"Results have been successfully saved to {full_path}")
    except Exception as e:
        logging.error(f"Failed to save results to {full_path}: {e}")

if __name__ == "__main__":
    main()
