
import numpy as np
from J_bootstrap import bootstrap

def choose(bucket):
    """Select a random integer value within the bucket interval."""
    return int(np.random.uniform(bucket[0], bucket[1]))

def average(values):
    arr = np.array(values, dtype=float)
    return np.nanmean(arr)

def top_2(values):
    return sorted(values, reverse=True)[:2]

def bottom_2(values):
    return sorted(values)[:2]

def set_rho(q, delta_target, epsilon_range, beta, k, tau, theta, b):
    accepted_rho = None
    size_theta = len(theta)
    num_buckets = int(np.ceil(size_theta / beta))
    epsilon_min, epsilon_max = epsilon_range

    g_star = float('inf')
    B_star = None

    print(f"Initialization: Num Buckets = {num_buckets}, Epsilon Range = [{epsilon_min}, {epsilon_max}]")

    for i in range(num_buckets):
        B_i = (i * beta, min((i + 1) * beta, size_theta))
        E_i = []
        print(f"\nProcessing Bucket {B_i}:")

        for j in range(k):

            # rho = choose(B_i, feedback, i, k)
            rho = choose(B_i)

            try:
                epsilon = bootstrap(theta, rho, delta_target, q, b)
            except ValueError as e:
                print(f"Error in bootstrap: {e}")
                continue

            print(f"    Iteration {j + 1}/{k}: rho = {rho}, epsilon = {epsilon}")

            E_i.append(epsilon)
            # feedback.append((rho, epsilon_min <= epsilon <= epsilon_max))

        if not E_i:
            print("Warning: E_i is empty. Skipping this bucket.")
            continue

        in_range_count = sum(epsilon_min <= e <= epsilon_max for e in E_i)

        print(f"q:{q}, delta_target:{delta_target}, beta: {beta}, k: {k}, tau: {tau}, B: {b}")
        print(f"Epsilons In Range [{epsilon_min}, {epsilon_max}]: {in_range_count}/{k}")

        fraction_in_range = in_range_count / k
        print(
            f"    Epsilons In Range [{epsilon_min}, {epsilon_max}]: {in_range_count}/{k} ({fraction_in_range * 100:.2f}%)")

        if fraction_in_range < tau:
            print(f"    Early Stopping Triggered for Bucket {B_i}, Fraction In Range Below {tau}")
            break

        rob_min = np.nanmean(sorted(E_i)[:2])
        rob_max = np.nanmean(sorted(E_i)[-2:])
        print(f"    Robust Min: {rob_min}")
        print(f"    Robust Max: {rob_max}")

        g_i = abs(rob_max - epsilon_max) + abs(rob_min - epsilon_min)

        print(f"    Robust Min: {rob_min}, Robust Max: {rob_max}, Gap: {g_i}")

        if g_i <= g_star:
            g_star = g_i
            B_star = B_i
            print(f"    New Best Gap: {g_star}, Bucket: {B_i}")

    if B_star is None:
        print("\nNo Optimal Bucket Found.")
        return None
    else:
        print(
            f"\nOptimal Bucket Found: {B_star}, with Median Rho: {np.median(B_star) if B_star else 'N/A'}")
        return np.median(B_star)

