import numpy as np


def bootstrap(theta, n, delta_target, q, b):
    theta = np.asarray(theta).flatten()
    n = min(n, len(theta))
    n = int(n) 
    print(f"n: {n}")

    epsilons = []

    S_0 = np.random.choice(theta, size=n, replace=True)

    x_0 = np.quantile(S_0, q)

    for _ in range(b):
        S_i = np.random.choice(theta, size=n, replace=True)
        # median_S_i = np.median(S_i)  # Calculate the median of the sample
        # difference_median = median_theta - median_S_i  # Calculate the difference
        # median_differences.append(difference_median)  # Optionally store difference_median if needed
        x_i = np.quantile(S_i, q)
        # print(f"abs(x_i - x_0)): {abs(x_i - x_0)}")
        epsilons.append(abs(x_i - x_0))

    # Diagnostic print to inspect the first few epsilon values
    epsilons.sort()

    # Calculate the index to select epsilon
    s_index = int(1 + b * (delta_target / 2)) - 1
    # difference_median_epsilon=difference_median-epsilons[s_index]
    print(f"s_index: {s_index}")
    print(f"epsilons[s_index]: {epsilons[s_index]}")

    return epsilons[s_index]
